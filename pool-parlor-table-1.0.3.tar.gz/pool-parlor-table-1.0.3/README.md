Pool Parlor Table


By:
Harry-T
Metaphira

Table uses a custom layer that has collisions disabled.

Usage:
Open the "Pool Parlor Table" scene in parallel with your world's scene.
Drag table into your scene.
