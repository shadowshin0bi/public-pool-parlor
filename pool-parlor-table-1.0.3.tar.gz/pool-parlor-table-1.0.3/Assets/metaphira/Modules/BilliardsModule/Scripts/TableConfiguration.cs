﻿using UnityEngine;

public class TableConfiguration : MonoBehaviour
{
   public TableConfigurationData config;
}
