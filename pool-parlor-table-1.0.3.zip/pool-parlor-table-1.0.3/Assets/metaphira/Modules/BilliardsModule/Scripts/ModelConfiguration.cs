﻿using UnityEngine;

public class ModelConfiguration : MonoBehaviour
{
   [SerializeField] [HideInInspector] public ModelConfigurationData data;
}
